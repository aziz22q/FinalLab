import lejos.nxt.LightSensor;
import lejos.nxt.SensorPort;
import lejos.nxt.SensorPortListener;
import lejos.nxt.Sound;
import lejos.robotics.navigation.DifferentialPilot;
import lejos.robotics.subsumption.Behavior;


public class Goal implements Behavior, SensorPortListener {
	
	private DifferentialPilot robot;
	private LightSensor lSensor;
	private boolean goalReached;
	private MoveNext b1 = null;
	
	public Goal(DifferentialPilot robot, LightSensor lSensor, MoveNext b1) {
		this.robot = robot;
		this.lSensor = lSensor;
		this.b1 = b1;
	}

	@Override
	public boolean takeControl() {
		return (!goalReached && lSensor.getLightValue() > 49);
		//return true;
	}

	@Override
	public void action() {
		b1.goalReached = true;
		Sound.playTone(250,  500);
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Sound.playTone(300,  500);
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Sound.playTone(500,  500);
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		robot.travel(20);
		robot.rotate(180);
		//System.out.println("light value: " + lSensor.getLightValue());
		//Sound.beep();
	}

	@Override
	public void suppress() {
		robot.stop();
	}
	
	@Override
	public void stateChanged(SensorPort aSource, int aOldValue, int aNewValue) {
		//System.out.println("light value: " + lSensor.getLightValue());
	}

}
