import lejos.nxt.SensorPort;
import lejos.nxt.SensorPortListener;
import lejos.nxt.TouchSensor;
import lejos.robotics.navigation.DifferentialPilot;
import lejos.robotics.subsumption.Behavior;


public class Avoid implements Behavior, SensorPortListener  {
	private DifferentialPilot robot;
	private TouchSensor tSensorF;
//	private Cell currentCell;
	public MoveNext b1 = null;

	public Avoid(DifferentialPilot robot, TouchSensor tSensorF, MoveNext b1) {
		this.robot = robot;
		this.tSensorF = tSensorF;
//		this.currentCell = b1.currentCell;
		this.b1 = b1;
		SensorPort.S1.addSensorPortListener(this);
	}

	@Override
	public boolean takeControl() {
		return tSensorF.isPressed();
	}

	@Override
	public void action() {
		System.out.println("pressed");
		b1.currentCell.setVisited(true);
		b1.currentCell.setCellValue(-1);
		b1.stack.removeElement(b1.currentCell);
		System.out.println("Obstacle: " + b1.currentCell.x + ", " + b1.currentCell.y);		
		
		robot.stop();
		try	{		
			 Thread.yield();	
			 Thread.sleep(1000);
		}catch(InterruptedException	ie)	{}
		robot.rotateRight();
		try	{		
			 Thread.yield();	
			 Thread.sleep(1000);
		}catch(InterruptedException	ie)	{}
		robot.stop();
	}

	@Override
	public void suppress() {
		robot.stop();
	}
	
	@Override
	public void stateChanged(SensorPort aSource, int aOldValue, int aNewValue) {
		System.out.println(tSensorF.isPressed());
		
	}

}
