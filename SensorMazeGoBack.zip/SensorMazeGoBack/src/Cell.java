
public class Cell {

    //Value pairs: 
    //-1: edges/obstacles
    //0: goal cell 
    //others: number of moves from goal
     
    public int x;
    public int y;
    private boolean visited = false;
    private boolean path = false;
    
    private int _cellValue = 0;
    
    public Cell(int x, int y){
            this.x = x;
            this.y = y;
    }
    
    public void setCellValue (int value){
            _cellValue = value;
    }
    
    public int getCellValue (){
            return _cellValue;
    }
    
    public void setVisited(boolean b){
            visited = b;
    }
    
    public boolean getVisited(){
            return visited;
    }

	public boolean getPath() {
		return path;
	}

	public void setPath() {
		path = true;
	}

}
