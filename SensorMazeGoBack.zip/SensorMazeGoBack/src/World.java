import java.util.ArrayList;
import java.util.Stack;

import lejos.nxt.comm.RConsole;


public class World {

        //create grid of the world, dimension 10x7
        private Cell[][] _grid;
        //width of the cell in degree
        private final static double _cellWidth = 409.3;
        //current cell
        private Cell currentCell;
        //arrayList for BFS
        ArrayList<Cell> cellValueArray = new ArrayList<Cell>();
        Stack<Cell> stack = new Stack<Cell>();
        private boolean goalReached = false;
        ArrayList<Cell> pathCells = new ArrayList<Cell>();


        private int _xGoal;
        private int _yGoal;
        
        private int w = 0;
        private int h = 0;
        
        public World(int width, int height){
        	this.w = width+1;
        	this.h = height+1;
        	
        	_grid = new Cell[width+2][height+2];
        	for(int j=0; j<height+2; j++){
    			for(int i=0; i<width+2; i++){
    				_grid[i][j] = new Cell(i, j);
    			}
        	}
        	//building wall
        	for(int i=0; i<width+2; i++){
        		_grid[i][0].setCellValue(-1);
        		_grid[i][0].setVisited(true);
        		_grid[i][height+1].setCellValue(-1);
        		_grid[i][height+1].setVisited(true);
        	}
        	for(int j=0; j<height+2; j++){
        		_grid[0][j].setCellValue(-1);
        		_grid[0][j].setVisited(true);
        		_grid[width+1][j].setCellValue(-1);
        		_grid[width+1][j].setVisited(true);
        	}
        }
        
        /**
         * 
         * @param toMove
         * @return
         */
        public double cellDistance(int toMove) {
                return (toMove * _cellWidth);
        }
        
        /**
         * Set the goal cell. 
         * @param x
         * @param y
         */
        public void setEnd(int x, int y){
                _xGoal = x;
                _yGoal = y;
                _grid[x][y].setCellValue(0);
        }
        
        /**
         * Build Obstacles, area specified by lower-left corner x1, y1; upper
         * @param x1
         * @param y1
         * @param x2
         * @param y2
         */
        public void buildObstacle(int x1, int y1, int x2, int y2){
                for (int i = x1; i <= x2; i++){
                        for (int j = y1; j <= y2; j++){
                                _grid[i][j].setCellValue(-1);
                                _grid[i][j].setVisited(true);
                        }
                }
        }
        
        /**
         * Robot's view of the world: where am I?
         * @param x
         * @param y
         */
        public void setStart(int x, int y){
                currentCell = _grid[x][y];
        }
        
        /**
         * 
         */
        public void populateWorld(){
                //BFS
                //Cell startingCell = _grid[_xGoal][_yGoal];
        		_grid[_xGoal][_yGoal].setVisited(true);
                cellValueArray.add(_grid[_xGoal][_yGoal]);
                
                System.out.println("xGoal: " + _xGoal + " yGoal " + _yGoal);
                
                while (!cellValueArray.isEmpty()){
                        Cell current = cellValueArray.remove(0);                        
                        //visit each of the 4 neighbors and add them to queue
                        if(!_grid[current.x + 1][current.y].getVisited()){
                        	_grid[current.x + 1][current.y].setVisited(true);
                        	_grid[current.x + 1][current.y].setCellValue(current.getCellValue() +1);
                            cellValueArray.add(_grid[current.x + 1][current.y]);
                        }
                        if(!_grid[current.x - 1][current.y].getVisited()){
                        	_grid[current.x - 1][current.y].setVisited(true);
                        	_grid[current.x - 1][current.y].setCellValue(current.getCellValue() +1);
                            cellValueArray.add(_grid[current.x - 1][current.y]);
                        }
                        if(!_grid[current.x][current.y+1].getVisited()){
                        	_grid[current.x][current.y+1].setVisited(true);
                        	_grid[current.x][current.y+1].setCellValue(current.getCellValue() +1);
                            cellValueArray.add(_grid[current.x][current.y+1]);
                        }
                        if(!_grid[current.x][current.y-1].getVisited()){
                        	_grid[current.x][current.y-1].setVisited(true);
                        	_grid[current.x][current.y-1].setCellValue(current.getCellValue() +1);
                            cellValueArray.add(_grid[current.x][current.y-1]);
                        }
                }
        }
        
        public void printGrid(){
//        	RConsole.open();
    		for(int j=h; j>-1; j--){
    			for(int i=0; i<w+1; i++){
        			System.out.print(_grid[i][j].getCellValue() + " ");
        		}
        		System.out.println("");
        	}
        }
        
        public void findPath() throws InterruptedException{
        	resetVisited();
        	stack.push(currentCell);
            dfs();
        }
        
        public Boolean isGoal(Cell cell){
        	return ((_xGoal==cell.x) && (_yGoal==cell.y));
        }
        
        public void dfs() throws InterruptedException {
        	Cell c = stack.pop();
        	c.setPath();
        	pathCells.add(c);
        	if(isGoal(c)){
        		goalReached = true;
        		
        		return;
        	}
        	else{
        		while(adjacent(c)){
        			dfs();
        			if(goalReached){
        				return;
        			}
        		}
        	}
        }
       
       private void resetVisited(){
       	for(int j=0; j<h+1; j++){
   			for(int i=0; i<w+1; i++){
   				_grid[i][j].setVisited(false);
   			}
       	}
       }
        
       private boolean adjacent(Cell c) throws InterruptedException {
    	   System.out.println("in World.adjecent curr: " + c.x + " " + c.y);
//    	   System.out.println("SIZE 1: " + _grid.);
    	   System.out.println("in World.adjecent curr: " + c.x + " " + c.y);
//    	   Thread.sleep(8000);
    	   if((_grid[c.x+1][c.y].getCellValue() != -1) && (_grid[c.x+1][c.y].getVisited() != true) && (_grid[c.x+1][c.y].getCellValue() < c.getCellValue())){
    		   _grid[c.x+1][c.y].setVisited(true);
    		   stack.push(_grid[c.x+1][c.y]);
    		   return true;
    	   }
    	   
    	   System.out.println("in World.adjecent 1");
//    	   Thread.sleep(8000);
    	   if((_grid[c.x-1][c.y].getCellValue() != -1) && _grid[c.x-1][c.y].getVisited() != true && (_grid[c.x-1][c.y].getCellValue() < c.getCellValue())){
    		   _grid[c.x-1][c.y].setVisited(true);
    		   stack.push(_grid[c.x-1][c.y]);
    		   return true;    	   
    	   }
    	   
    	   System.out.println("in World.adjecent 2");
//    	   Thread.sleep(8000);
    	   if((_grid[c.x][c.y+1].getCellValue() != -1) && _grid[c.x][c.y+1].getVisited() != true && (_grid[c.x][c.y+1].getCellValue() < c.getCellValue())){
    		   _grid[c.x][c.y+1].setVisited(true);
    		   stack.push(_grid[c.x][c.y+1]);
    		   return true;    	   
    	   }
    	   
    	   System.out.println("in World.adjecent 3");
//    	   Thread.sleep(8000);
    	   if((_grid[c.x][c.y-1].getCellValue() != -1) && _grid[c.x][c.y-1].getVisited() != true && (_grid[c.x][c.y-1].getCellValue() < c.getCellValue())){
    		   _grid[c.x][c.y-1].setVisited(true);
    		   stack.push(_grid[c.x][c.y-1]);
    		   return true;    	   
    	   }
    	   
    	   return false;
		}
       
       
       public ArrayList<Cell> getPath(){
    	   return pathCells;
       }
}