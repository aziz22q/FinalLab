import lejos.nxt.Button;
import lejos.nxt.LCD;
import lejos.nxt.LightSensor;
import lejos.nxt.Motor;
import lejos.nxt.SensorPort;
import lejos.nxt.TouchSensor;
import lejos.robotics.*;
import lejos.robotics.navigation.*;
import lejos.robotics.subsumption.*;

public class Main {

	public static final int TRAVEL_DIST = 20;
//    private static Cell currentCell;
//    private static boolean goalReached = false;
    

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("starting!");

		int startX = 1;
		int startY = 1;
		
		DifferentialPilot robot = new DifferentialPilot(5.6f, 11.0f, Motor.A,
				Motor.C, false);
		robot.setRotateSpeed(7);
		robot.setTravelSpeed(9);
		TouchSensor tSensorF = new TouchSensor(SensorPort.S1);
		LightSensor lSensor = new LightSensor(SensorPort.S3);
		System.out.println("before move next!");

		Behavior b1 = new MoveNext(robot, startX, startY);	
		System.out.println("after move next!");

		Behavior b2 = new Avoid(robot, tSensorF, (MoveNext) b1);
		Behavior b3 = new Goal(robot, lSensor, (MoveNext) b1);
		Behavior[] bArray = { b1, b2, b3 };
		Arbitrator arby = new Arbitrator(bArray);

		arby.start();
		Button.waitForAnyPress();

	}
}