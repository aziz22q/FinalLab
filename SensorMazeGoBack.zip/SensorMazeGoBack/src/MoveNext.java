import java.util.ArrayList;
import java.util.Stack;

import lejos.robotics.navigation.DifferentialPilot;
import lejos.robotics.subsumption.Behavior;


public class MoveNext implements Behavior {
	
	private DifferentialPilot robot;
	static int rotateDeg = 410;
	int distance = 0;

	private Cell[][] _grid = new Cell[10][7];
    public boolean goalReached = false;
    public Cell currentCell = null;
    private Cell prevCell;
    public String s = "";
    public Stack<Cell> stack = new Stack<Cell>();
    ArrayList<Cell> pathCells = new ArrayList<Cell>();
	ArrayList<String> path = new ArrayList<String>();
	private int _startX = 0;
	private int _startY = 0;


	public MoveNext(DifferentialPilot robot, int x, int y) {
		this._startX = x;
		this._startY = y;
		this.robot = robot;
//		this.currentCell = currentCell;
		
    	for(int j=0; j<7; j++){
			for(int i=0; i<10; i++){
				_grid[i][j] = new Cell(i, j);
			}
    	}
    	//building wall
    	for(int i=0; i<10; i++){
    		_grid[i][0].setCellValue(-1);
    		_grid[i][0].setVisited(true);
    		_grid[i][6].setCellValue(-1);
    		_grid[i][6].setVisited(true);
    		
    		if(i!=0 && i!=9){
        		_grid[i][1].setCellValue(3);
        		_grid[i][5].setCellValue(3);
    		}
    	}
    	for(int j=0; j<7; j++){
    		_grid[0][j].setCellValue(-1);
    		_grid[0][j].setVisited(true);
    		_grid[9][j].setCellValue(-1);
    		_grid[9][j].setVisited(true);
    		
    		if(j!=0 && j!=6){
        		_grid[1][j].setCellValue(3);
        		_grid[8][j].setCellValue(3);
    		}
    	}
    	
    	for(int i=2; i<=7; i++){
    		for(int j=2; j<=4; j++){
    			_grid[i][j].setCellValue(4);
    		}
    	}
    	

    	_grid[1][1].setCellValue(2);
    	_grid[1][5].setCellValue(2);
    	_grid[8][1].setCellValue(2);
    	_grid[8][5].setCellValue(2);
    	
        currentCell = _grid[x][y];
        prevCell = _grid[x][y];
        currentCell.setVisited(true);
//    	stack.push(currentCell);
	}

	
	@Override
	public boolean takeControl() {
		return true;
	}

	@Override
	public void action() {
		
		if(goalReached){
			System.out.println("Goal: " + currentCell.x + " " + currentCell.y);
			World gobackWorld = new World(currentCell.x, currentCell.y);
			
			//update the obstacle for gobackWorld
	    	for(int j = _startY; j < currentCell.y+1; j++){
				for(int i = _startX; i < currentCell.x+1; i++){
					if(this._grid[i][j].getCellValue() == -1 || (!this._grid[i][j].getVisited() && !this._grid[i][j].equals(currentCell))){
						gobackWorld.buildObstacle(i, j, i, j);
					}
				}
	    	}			
	    	
	    	//set starting point for gobackWorld
	    	gobackWorld.setStart(currentCell.x, currentCell.y);
	    	gobackWorld.setEnd(_startX, _startY);
	    	//populate the world
	    	gobackWorld.populateWorld();
	    	gobackWorld.printGrid();
	    	try {
				Thread.sleep(20000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
			}
	    	try {
				gobackWorld.findPath();
			} catch (InterruptedException e) {
			}
//	    	decodePath(gobackWorld);
//	    	move();
	    	
	    	pathCells.add(currentCell);
			goBack();
	    	try {
				Thread.sleep(20000);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
			}
			decodePath();
			System.out.println("I'm doneeeeeee, kinda!");
			System.exit(0);
		}
		
		if (currentCell.getCellValue() > 1){
			stack.push(prevCell);
		}
		if(currentCell.getCellValue() == -1){
			System.out.println("currentCell is -1");
			pathCells.remove(currentCell);
			stack.removeElement(currentCell);
			currentCell = prevCell;
			currentCell.setCellValue(currentCell.getCellValue() -1);
		}
		
		//add to path cells
		if(currentCell.getCellValue() > 1 && !pathCells.contains(currentCell)){
			pathCells.add(currentCell);
		}
		
		adjacent(currentCell);


		if(stack.empty() && currentCell.getCellValue() == 1){
			System.out.println("DeadEnd!!!");
			System.exit(0);
		}
		while (stack.peek().getCellValue() == 1){
			System.out.println("PEEKED CELL: " + stack.peek().x + " " + stack.peek().y + " ");
			stack.pop();
		}
		Cell c = stack.pop();
		System.out.println("POPPED: " + (c.x) +","+ (c.y));
		System.out.println("VALUE: " + c.getCellValue());


		// when it has to backtrack
		if (c.equals(prevCell)){
			try	{		
				 Thread.yield();	
				 Thread.sleep(1000);
			}catch(InterruptedException	ie)	{}
			
			//reset the prev cell
			prevCell = currentCell;
		}
		//CORNER CHECKING!!!

	   if(((prevCell.x != c.x) && (prevCell.y != c.y))){
		   //corner! 				   			   
		   if(((c.x > prevCell.x) && (c.y > prevCell.y)) || (c.x < prevCell.x) && (c.y < prevCell.y)){
			   if(currentCell.x == c.x){
					robot.rotateLeft();
					try	{		
						 Thread.yield();	
						 Thread.sleep(1000);
					}catch(InterruptedException	ie)	{}
			   }
			   else{
					robot.rotateRight();
					try	{		
						 Thread.yield();	
						 Thread.sleep(1000);
					}catch(InterruptedException	ie)	{}
			   }
		   }
		   else{
			   if(currentCell.x == c.x){
					robot.rotateRight();
					try	{		
						 Thread.yield();	
						 Thread.sleep(1000);
					}catch(InterruptedException	ie)	{}
			   }
			   else{
					robot.rotateLeft();
					try	{		
						 Thread.yield();	
						 Thread.sleep(1000);
					}catch(InterruptedException	ie)	{}			   
			   }
		   }
			robot.travel(20);
			try	{		
				 Thread.yield();	
				 Thread.sleep(1000);
			}catch(InterruptedException	ie)	{}
			robot.stop();
	   }
	   else{
			robot.travel(20);
			try	{		
				 Thread.yield();	
				 Thread.sleep(1000);
			}catch(InterruptedException	ie)	{}
			robot.stop();
	   }
	   		
		//push curr cell in if not 1
//	   if (currentCell.getCellValue() != 1 && !stack.peek().equals(currentCell)){
//	   if (currentCell.getCellValue() != 1 ){
//
//			stack.push(currentCell);
//	   }
		prevCell = currentCell;
		currentCell.setVisited(true);
		currentCell = c;
//		   System.out.println("FINISHED MOVING!");

	}
	
    private void goBack() {
    	ArrayList<Cell> newPath = new ArrayList<Cell>();
    	for(int i = pathCells.size()-1; i >= 0; i--){
    		if(pathCells.get(i).getCellValue() >=2){
    			System.out.println("ADDED: "+ pathCells.get(i).x +"," + pathCells.get(i).y);
        		newPath.add(pathCells.get(i));
    		}
    	}
    	pathCells = newPath;
	}
//    
//	public void decodePath(World world) {
//		pathCells = world.getPath();
//		int index = 1;
//		int corner = pathCells.get(0).getCellValue();
//		Cell c1;
//		Cell c2 = pathCells.get(0);
//		while (c2.getCellValue() != 0) {
//			c1 = pathCells.get(index - 1);
//			c2 = pathCells.get(++index);
//
//			if (c2.getCellValue() == 0) {
//				path.add(Integer.toString(corner));
//				break;
//			}
//			if (((c1.x != c2.x) && (c1.y != c2.y))) {
//				// corner!
//				path.add(Integer.toString((corner - pathCells.get(index - 1)
//						.getCellValue())));
//				corner = pathCells.get(index - 1).getCellValue();
//
//				if (((c2.x > c1.x) && (c2.y > c1.y)) || (c2.x < c1.x)
//						&& (c2.y < c1.y)) {
//					if (pathCells.get(index - 1).x == c2.x) {
//						path.add("L");
//					} else {
//						path.add("R");
//					}
//				} else {
//					if (pathCells.get(index - 1).x == c2.x) {
//						path.add("R");
//					} else {
//						path.add("L");
//					}
//				}
//			}
//		}
//		System.out.println("PATH: " + path.toString());
//	}
//	
//	public void move() {
////		int distance;
//		while (!path.isEmpty()) {
//
//			if (path.size() % 2 == 0) {
//				String move = path.remove(0);
//				//distance = turn;
//				if (move.equals("R")) {
//					robot.rotateRight();
//				} else {
//					robot.rotateLeft();
//				}
//			} else {
////				int moveInt = Integer.parseInt(path.remove(0));
////				distance = rotateDeg * moveInt;
////				System.out.print("moving forward: " + distance);
//				robot.travel(20);
//			}
//		}
//
//	}
	public void decodePath(){
 	   int index = 1;
	   Cell curr = pathCells.get(0);
	   Cell prev = pathCells.get(0);
	   Cell next = pathCells.get(0);
 	   while(index <= pathCells.size()){
 		   
 		   System.out.println("going baaaaaaack: " + curr.x + ":" + curr.y);
 		   
 		   next = pathCells.get(index++);
 		   
 		   if(((prev.x != next.x) && (prev.y != next.y))){
 			   //corner! 				   			   
 			   if(((next.x > prev.x) && (next.y > prev.y)) || (next.x < prev.x) && (next.y < prev.y)){
 				   if(curr.x == next.x){
 						robot.rotateLeft();
 						try	{		
 							 Thread.yield();	
 							 Thread.sleep(1000);
 						}catch(InterruptedException	ie)	{}
 				   }
 				   else{
 						robot.rotateRight();
 						try	{		
 							 Thread.yield();	
 							 Thread.sleep(1000);
 						}catch(InterruptedException	ie)	{}
 				   }
 			   }
 			   else{
 				   if(curr.x == next.x){
 						robot.rotateRight();
 						try	{		
 							 Thread.yield();	
 							 Thread.sleep(1000);
 						}catch(InterruptedException	ie)	{}
 				   }
 				   else{
 						robot.rotateLeft();
 						try	{		
 							 Thread.yield();	
 							 Thread.sleep(1000);
 						}catch(InterruptedException	ie)	{}			   
 				   }
 			   }
 				robot.travel(20);
 				try	{		
 					 Thread.yield();	
 					 Thread.sleep(1000);
 				}catch(InterruptedException	ie)	{}
 				robot.stop();
 		   }
 		   else{
 				robot.travel(20);
 				try	{		
 					 Thread.yield();	
 					 Thread.sleep(1000);
 				}catch(InterruptedException	ie)	{}
 				robot.stop();
 		   }
 		   prev = curr;
 		   curr = pathCells.get(index-1);
 	   }
	}

	private void adjacent(Cell c) { 
//		System.out.println("is stack emptyyyyyyyyyyyy: " + (stack.isEmpty()));
		
		//counter
		int stackCounter = stack.size();
		if((_grid[c.x-1][c.y].getCellValue() != -1) && (_grid[c.x-1][c.y].getCellValue() != 1) && (_grid[c.x-1][c.y].getVisited() != true)){
// 		   _grid[c.x-1][c.y].setVisited(true);
// 		   if(stack.search(_grid[c.x-1][c.y]) ==-1){
// 				System.out.println("push left: " + (c.x-1) + (c.y));
 	 		   stack.push(_grid[c.x-1][c.y]);
// 		   }
 	   }
 	   if((_grid[c.x][c.y-1].getCellValue() != -1) && (_grid[c.x][c.y-1].getCellValue() != -1) && (_grid[c.x][c.y-1].getVisited() != true)){
// 		   _grid[c.x][c.y-1].setVisited(true);
// 		   if(stack.search(_grid[c.x][c.y-1]) ==-1){
//				System.out.println("push top: " + (c.x) + (c.y-1));
 	 		   stack.push(_grid[c.x][c.y-1]);
// 		   }
 	   }
	 	
 	   if((_grid[c.x+1][c.y].getCellValue() != -1) && (_grid[c.x+1][c.y].getCellValue() !=1) && (_grid[c.x+1][c.y].getVisited() != true)){
// 		   _grid[c.x+1][c.y].setVisited(true);
// 		   if(stack.search(_grid[c.x+1][c.y]) ==-1){
//				System.out.println("push right: " + (c.x+1) + (c.y));
 	 		   stack.push(_grid[c.x+1][c.y]);
// 		   }
 	   }
 	   
 	   if((_grid[c.x][c.y+1].getCellValue() != -1) && (_grid[c.x][c.y+1].getCellValue() != 1) && (_grid[c.x][c.y+1].getVisited() != true) ){
// 		   _grid[c.x][c.y+1].setVisited(true);
// 		   if(stack.search(_grid[c.x][c.y+1]) ==-1){
//				System.out.println("push bottom: " + (c.x) + (c.y+1));
 	 		   stack.push(_grid[c.x][c.y+1]);
// 		   }
 	   }
 	   
 	   if (stackCounter == stack.size()){
 		   c.setCellValue(1);
 	   }
 	   
	}
    

	@Override
	public void suppress() {
		robot.stop();
	}

}
